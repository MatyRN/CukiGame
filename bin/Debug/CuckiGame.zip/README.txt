-HOLA SOY MATIASRN-
Dejo este archivo de texto para que sepan que es seguro, y si se preguntan porque es un acceso directo el .exe es porque
no encontre la manera con este metodo programado de agregar un icono asi que esa fue la unica manera que encontre.
Igual si no me creen voy a pasar el codigo, y si buscan el ejecutable esta en archivos, tambien pueden modificar los propios
items para añadir otros.
Se que es algo simple pero me costo mucho, cualquier añadido o cambio avisenme.
